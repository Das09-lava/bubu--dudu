BUBU & DUDU WEBSITE

1. Keep index.html, style.css, script.js and the images folder together.
2. Open index.html in Chrome to preview the website.
3. For GitHub, upload index.html, style.css, script.js and the complete images folder to the repository root.
4. The page uses images/photo1.jpg through images/photo10.jpg.
5. To publish, enable GitHub Pages from Settings > Pages and deploy from main / (root).
