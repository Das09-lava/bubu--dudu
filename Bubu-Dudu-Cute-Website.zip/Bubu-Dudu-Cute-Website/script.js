const gallery = document.getElementById("gallery");
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const lightboxCaption = document.getElementById("lightboxCaption");

gallery.addEventListener("click", (event) => {
  const card = event.target.closest(".photo-card");
  if (!card) return;
  const image = card.querySelector("img");
  lightboxImage.src = image.src;
  lightboxImage.alt = image.alt;
  lightboxCaption.textContent = card.querySelector("figcaption").textContent;
  lightbox.classList.add("open");
});

function closeLightbox() {
  lightbox.classList.remove("open");
  lightboxImage.src = "";
}
document.getElementById("closeLightbox").addEventListener("click", closeLightbox);
lightbox.addEventListener("click", (event) => {
  if (event.target === lightbox) closeLightbox();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeLightbox();
});

function makeHeart() {
  const heart = document.createElement("span");
  heart.className = "floating-heart";
  heart.textContent = ["♡", "♥", "💕", "💗"][Math.floor(Math.random() * 4)];
  heart.style.left = Math.random() * 100 + "vw";
  heart.style.fontSize = (18 + Math.random() * 22) + "px";
  document.querySelector(".floating-hearts").appendChild(heart);
  setTimeout(() => heart.remove(), 4100);
}
document.getElementById("heartButton").addEventListener("click", () => {
  document.getElementById("heartMessage").textContent = "A little happiness sent your way! 💗";
  for (let i = 0; i < 18; i++) setTimeout(makeHeart, i * 90);
});
